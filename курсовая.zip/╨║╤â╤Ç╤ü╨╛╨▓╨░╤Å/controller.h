#include <iostream>
#include "orders.h"

class controller {
private:
    fabrika currentService;
public:
    controller() {}
    
    void execute() {
        bool run = true;
        while (run) {
            menu();
            int var = 0;
            while (var < 1 || var > 8) {
                cout << "Input variant: ";
                cin >> var;
            }
            switch (var) {
                case 8:
                    run = false;
                    break;
                case 1:
                    currentService.print();
                    break;
                case 2:
                    currentService.addRc();
                    cout << "zakaz sozdan!";
                    break;
                case 3:
                    currentService.print();
                    cout << "vvedite nomer zakaza kotoriy nado delete:\n";
                    int n;
                    cin >> n;
                    currentService.deleteRc(n);
                    break;
                case 4:
                    currentService.saveToFile(true);
                    cout << "zakazi soxraneni!" << endl;
                    break;
                case 5:
                    currentService.saveToFile(false);
                    break;
                case 6:
                    currentService.loadFile();
                    cout << "zakazi iz faila uspeshno zagruzheni!" << endl;
                    break;
                case 7:
                    cout << "viberite zakaz dlya redaktirovaniya:" << endl;
                    int choose = 0;
                    while (choose < 1 || choose > currentService.getN() + 1) {
                        currentService.print();
                        cout << "[" << currentService.getN() + 1 << "] " << "otmena." << endl;
                        cin >> choose;
                    }
                    currentService.changeRecord(choose);
                    cout << "zakaz!" << endl;
                    break;
            }
        }
    }

    void menu() {
        std::cout << "Commands: " << endl;
        std::cout << "[1] vivesti vse zakazi" << endl;
        std::cout << "[2] sozdat novuyu zapis vzakaze" << endl;
        std::cout << "[3] udalit zapis o zakaze" << endl;
        std::cout << "[4] dobavit tekushie zakazi v fail" << endl;
        std::cout << "[5] perezapisat tekushiy fail s zakazami" << endl;
        std::cout << "[6] zagruzit zakazi iz faila" << endl;
        std::cout << "[7] otredaktirovat zakazi" << endl;
        std::cout << "[8] exit" << endl;
    }
};
