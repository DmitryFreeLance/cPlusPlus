#include <iostream>
#include <vector>

class Stack {
private:
    struct Node {
        int data;
        Node* next;
        Node(int d) : data(d), next(nullptr) {}
    };
    
    Node* top;

public:
    Stack() : top(nullptr) {}

    bool isEmpty() {
        return top == nullptr;
    }

    void push(int value) {
        Node* newNode = new Node(value);
        newNode->next = top;
        top = newNode;
    }

    int pop() {
        if (isEmpty()) {
            throw std::out_of_range("Stack is empty");
        }
        Node* temp = top;
        int value = temp->data;
        top = top->next;
        delete temp;
        return value;
    }
    
    ~Stack() {
        while (!isEmpty()) {
            pop();
        }
    }
};

class Graph {
private:
    int V;
    std::vector<std::vector<int>> adjMatrix;

    void DFSUtil(int v, std::vector<bool>& visited) {
        visited[v] = true;
        std::cout << v << " ";

        for (int i = 0; i < V; ++i) {
            if (adjMatrix[v][i] == 1 && !visited[i]) {
                DFSUtil(i, visited);
            }
        }
    }

public:
    Graph(int V) : V(V), adjMatrix(V, std::vector<int>(V, 0)) {}

    void addEdge(int v, int w) {
        adjMatrix[v][w] = 1;
        adjMatrix[w][v] = 1;
    }

    void DFSIterative(int start) {
        std::vector<bool> visited(V, false);
        Stack stack;

        stack.push(start);

        while (!stack.isEmpty()) {
            int v = stack.pop();

            if (!visited[v]) {
                std::cout << v << " ";
                visited[v] = true;
            }

            for (int i = V - 1; i >= 0; --i) {
                if (adjMatrix[v][i] == 1 && !visited[i]) {
                    stack.push(i);
                }
            }
        }
    }

    void DFSRecursive(int start) {
        std::vector<bool> visited(V, false);
        DFSUtil(start, visited);
    }
};

int main() {
    Graph g(4);
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 2);
    g.addEdge(2, 0);
    g.addEdge(2, 3);
    g.addEdge(3, 3);

    std::cout << "Depth First Traversal (Iterative, starting from vertex 2): ";
    g.DFSIterative(2);
    std::cout << std::endl;

    std::cout << "Depth First Traversal (Recursive, starting from vertex 2): ";
    g.DFSRecursive(2);
    std::cout << std::endl;

    return 0;
}