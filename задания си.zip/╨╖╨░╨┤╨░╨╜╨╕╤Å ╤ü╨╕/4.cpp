#include <iostream>
#include <vector>
#include <queue>
#include <climits>
#include <algorithm>

class Graph {
public:
    int V; // Количество вершин
    std::vector<std::vector<int>> distanceMatrix;
    std::vector<std::vector<int>> timeMatrix;
    std::vector<std::vector<int>> costMatrix;

public:
    Graph(int V) : V(V), 
                   distanceMatrix(V, std::vector<int>(V, INT_MAX)), 
                   timeMatrix(V, std::vector<int>(V, INT_MAX)), 
                   costMatrix(V, std::vector<int>(V, INT_MAX)) {}

    void addEdge(int u, int v, int distance, int time, int cost) {
        distanceMatrix[u][v] = distance;
        distanceMatrix[v][u] = distance; // Для неориентированного графа

        timeMatrix[u][v] = time;
        timeMatrix[v][u] = time; // Для неориентированного графа

        costMatrix[u][v] = cost;
        costMatrix[v][u] = cost; // Для неориентированного графа
    }

    std::vector<int> dijkstra(const std::vector<std::vector<int>>& matrix, int src) {
        std::vector<int> dist(V, INT_MAX);
        std::vector<bool> sptSet(V, false);
        dist[src] = 0;

        for (int count = 0; count < V - 1; count++) {
            int u = minDistance(dist, sptSet);
            sptSet[u] = true;

            for (int v = 0; v < V; v++) {
                if (!sptSet[v] && matrix[u][v] != INT_MAX && dist[u] != INT_MAX && dist[u] + matrix[u][v] < dist[v]) {
                    dist[v] = dist[u] + matrix[u][v];
                }
            }
        }
        return dist;
    }

    std::vector<std::pair<int, int>> primMST(const std::vector<std::vector<int>>& matrix) {
        std::vector<int> key(V, INT_MAX);
        std::vector<bool> inMST(V, false);
        std::vector<int> parent(V, -1);
        key[0] = 0;

        for (int count = 0; count < V - 1; count++) {
            int u = minKey(key, inMST);
            inMST[u] = true;

            for (int v = 0; v < V; v++) {
                if (matrix[u][v] && matrix[u][v] < key[v] && !inMST[v]) {
                    parent[v] = u;
                    key[v] = matrix[u][v];
                }
            }
        }

        std::vector<std::pair<int, int>> mstEdges;
        for (int i = 1; i < V; i++) {
            mstEdges.push_back({parent[i], i});
        }
        return mstEdges;
    }

private:
    int minDistance(const std::vector<int>& dist, const std::vector<bool>& sptSet) {
        int min = INT_MAX, minIndex;

        for (int v = 0; v < V; v++) {
            if (!sptSet[v] && dist[v] <= min) {
                min = dist[v];
                minIndex = v;
            }
        }
        return minIndex;
    }

    int minKey(const std::vector<int>& key, const std::vector<bool>& inMST) {
        int min = INT_MAX, minIndex;

        for (int v = 0; v < V; v++) {
            if (!inMST[v] && key[v] < min) {
                min = key[v];
                minIndex = v;
            }
        }
        return minIndex;
    }
};

class TravelSystem {
private:
    Graph graph;

public:
    TravelSystem(int V) : graph(V) {}

    void addFlight(int u, int v, int distance, int time, int cost) {
        graph.addEdge(u, v, distance, time, cost);
    }

    std::vector<int> findShortestTime(int src, int dest) {
        return graph.dijkstra(graph.timeMatrix, src);
    }

    std::vector<int> findCheapestCost(int src, int dest) {
        return graph.dijkstra(graph.costMatrix, src);
    }

    std::vector<std::pair<int, int>> findMinSpanningTreeByDistance() {
        return graph.primMST(graph.distanceMatrix);
    }

    std::vector<std::pair<int, int>> findMinSpanningTreeByTime() {
        return graph.primMST(graph.timeMatrix);
    }

    std::vector<std::pair<int, int>> findMinSpanningTreeByCost() {
        return graph.primMST(graph.costMatrix);
    }
};

int main() {
    TravelSystem ts(5);

    ts.addFlight(0, 1, 100, 1, 50);
    ts.addFlight(0, 2, 300, 4, 150);
    ts.addFlight(1, 2, 200, 2, 100);
    ts.addFlight(1, 3, 400, 3, 200);
    ts.addFlight(2, 3, 100, 1, 50);
    ts.addFlight(3, 4, 500, 5, 300);

    int src = 0;
    int dest = 4;

    std::vector<int> shortestTime = ts.findShortestTime(src, dest);
    std::vector<int> cheapestCost = ts.findCheapestCost(src, dest);

    std::vector<std::pair<int, int>> mstByDistance = ts.findMinSpanningTreeByDistance();
    std::vector<std::pair<int, int>> mstByTime = ts.findMinSpanningTreeByTime();
    std::vector<std::pair<int, int>> mstByCost = ts.findMinSpanningTreeByCost();

    std::cout << "Shortest Time to " << dest << ": " << shortestTime[dest] << std::endl;
    std::cout << "Cheapest Cost to " << dest << ": " << cheapestCost[dest] << std::endl;

    std::cout << "Minimum Spanning Tree by Distance:" << std::endl;
    for (const auto& edge : mstByDistance) {
        std::cout << edge.first << " - " << edge.second << std::endl;
    }

    std::cout << "Minimum Spanning Tree by Time:" << std::endl;
    for (const auto& edge : mstByTime) {
        std::cout << edge.first << " - " << edge.second << std::endl;
    }

    std::cout << "Minimum Spanning Tree by Cost:" << std::endl;
    for (const auto& edge : mstByCost) {
        std::cout << edge.first << " - " << edge.second << std::endl;
    }

    return 0;
}
