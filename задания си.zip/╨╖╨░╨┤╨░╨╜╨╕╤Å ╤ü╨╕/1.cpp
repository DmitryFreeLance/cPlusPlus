#include <iostream>
#include <vector>
#include <list>

class Queue {
private:
    struct Node {
        int data;
        Node* next;
        Node(int d) : data(d), next(nullptr) {}
    };
    
    Node* front;
    Node* rear;

public:
    Queue() : front(nullptr), rear(nullptr) {}

    bool isEmpty() {
        return front == nullptr;
    }

    // Добавление в конец
    void enqueue(int value) {
        Node* newNode = new Node(value);
        if (rear) {
            rear->next = newNode;
        }
        rear = newNode;
        if (!front) {
            front = newNode;
        }
    }

    // Получение из начала
    int dequeue() {
        if (isEmpty()) {
            throw std::out_of_range("Queue is empty");
        }
        Node* temp = front;
        int value = temp->data;
        front = front->next;
        if (!front) {
            rear = nullptr;
        }
        delete temp;
        return value;
    }
    
    ~Queue() {
        while (!isEmpty()) {
            dequeue();
        }
    }
};
class Graph {
private:
    int V;
    std::vector<std::list<int>> adj;

public:
    Graph(int V) : V(V), adj(V) {}

    void addEdge(int v, int w) {
        adj[v].push_back(w);
    }

    void BFS(int s) {
        std::vector<bool> visited(V, false);
        Queue queue;

        visited[s] = true;
        queue.enqueue(s);

        while (!queue.isEmpty()) {
            s = queue.dequeue();
            std::cout << s << " ";

            for (auto adjVertex : adj[s]) {
                if (!visited[adjVertex]) {
                    visited[adjVertex] = true;
                    queue.enqueue(adjVertex);
                }
            }
        }
    }
};

int main() {
    Graph g(4);
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 2);
    g.addEdge(2, 0);
    g.addEdge(2, 3);
    g.addEdge(3, 3);

    std::cout << "Breadth First Traversal (starting from vertex 2): ";
    g.BFS(2);

    return 0;
}